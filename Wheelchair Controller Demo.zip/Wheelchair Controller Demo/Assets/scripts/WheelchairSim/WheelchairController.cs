﻿using UnityEngine;
using System;
using WheelchairSerialConnect;
using UnityEngine.VR;

public class WheelchairController : MonoBehaviour
{
	//Should keyboard be used instead of wheelchair
	[SerializeField] private bool _useKeyboardMovement;
	//Speed multiplier for wheelchair wheelcolliders
    [SerializeField] private float _motorSpeed = 30;

    [SerializeField] private WheelCollider _wheelLeft;
    [SerializeField] private WheelCollider _wheelRight;

    private Connector connector;

    void Start () {
        connector = Connector.getInstance();
        connector.AutoConnect();
    }
    
    void FixedUpdate(){
        if (_useKeyboardMovement)
        {
            float leftMotor = (Input.GetKey(KeyCode.D)) ? _motorSpeed : 0;
            float rightMotor = (Input.GetKey(KeyCode.A)) ? _motorSpeed : 0;
            _wheelLeft.motorTorque = leftMotor;
            _wheelRight.motorTorque = rightMotor;
        }
        else
        {
            Movement m = connector.Collect();
            _wheelLeft.motorTorque = m.LeftTicks*_motorSpeed;
            _wheelRight.motorTorque = m.RightTicks*_motorSpeed;
        }
	}

    void OnApplicationQuit()
    {
        if (connector != null)
            connector.Disconnect();
    }

}
